package com.nau.main;

import com.nau.viewcontroller.GreetController;

public class MainApp {
	
	public static void main(String[] args) {
		
		GreetController controller = new GreetController();
		controller.greetings("RK");
		
	}

}
