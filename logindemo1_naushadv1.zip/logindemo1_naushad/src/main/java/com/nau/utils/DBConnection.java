package com.nau.utils;

import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public class DBConnection {

	private static Connection connection;

	static {
		try {
			Properties properties = new Properties();
		//	properties.load(new FileReader("db.properties"));
			properties.load(ClassLoader.getSystemResourceAsStream("db.properties"));
			String url = properties.getProperty("url");
			String username = properties.getProperty("username");
			String password = properties.getProperty("password");;
			connection = DriverManager.getConnection(url,username,password);
			System.out.println("Connection Established");
		} catch (SQLException | IOException e) {
			e.printStackTrace();
		}
	}
	public static Connection getConnection() {
		return connection;
	}

}
