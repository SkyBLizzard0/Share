package com.nau.dao;

public class MessengerNameDao {
	
	
	public void saveName(String name) {
		
		
	}

}
