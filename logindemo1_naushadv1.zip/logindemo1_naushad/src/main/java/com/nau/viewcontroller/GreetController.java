package com.nau.viewcontroller;

import com.nau.service.GreetingService;

public class GreetController {
	
	public GreetController() {
		
	}
	public String greetings(String name) {
		GreetingService greeting = new GreetingService();
		String message = greeting.greet(name);
		System.out.println(message);
		return message;
	}
	

}
