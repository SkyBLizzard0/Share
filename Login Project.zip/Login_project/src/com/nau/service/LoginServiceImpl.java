package com.nau.service;

import java.util.Arrays;
import java.util.List;

import com.nau.dao.LoginDaoImpl;
import com.nau.model.Login;

public class LoginServiceImpl extends LoginServiceAdaptor{

	private LoginDaoImpl logindao = new LoginDaoImpl();
 @Override
public Integer addUser(Login... logins) {
	
	 List<Login> loginslist = Arrays.asList(logins);
	 for(Login login: loginslist) {
		 login.setFname(login.getFname().toUpperCase());
		 login.setLname(login.getLname().toUpperCase());
	 } 
	return 0;
}
}
