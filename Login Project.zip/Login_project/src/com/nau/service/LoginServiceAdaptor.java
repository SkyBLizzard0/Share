package com.nau.service;

import java.util.List;

import com.nau.model.Login;

public abstract class LoginServiceAdaptor implements LoginService {   //if class is abstract we cannot create object

	@Override
	public Login getUserByIdAndPassword(Integer userId, String password) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer addUser(Login... login) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Login getUserById(Integer userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Boolean updatePassword(Integer userId, String newPassword) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Integer deleteUser(Integer... userId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Login> getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}

}
