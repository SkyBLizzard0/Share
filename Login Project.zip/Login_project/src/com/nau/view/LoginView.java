package com.nau.view;

import java.util.*;

import com.nau.model.Login;
import com.nau.service.LoginService;
import com.nau.service.LoginServiceImpl;


public class LoginView {

	private Scanner input = new Scanner(System.in);
	public LoginView() {
		login();
	}

	private void login() {
		// TODO Auto-generated method stub
		System.out.println("********************Login******************");
		System.out.println("Enter UserId: ");
		Integer userId = input.nextInt();
		System.out.println("Enter Password: ");
		String password = input.next();
		System.out.println(userId+ " "+ password);
//		Login login = new Login(userId, password);
		LoginService loginService = new LoginServiceImpl();
	}
}
