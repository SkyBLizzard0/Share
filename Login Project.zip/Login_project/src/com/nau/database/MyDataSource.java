package com.nau.database;

import java.sql.*;

public class MyDataSource {

	public static void main(String[] args) throws SQLException {
//		Driver driver = new com.mysql.cj.jdbc.Driver();
//		DriverManager.registerDriver(driver);
		Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/rk_ey","rk","password");
		System.out.println("Connected");
//		String sql1 = "insert into login values(111,'nau25','Naushad','Akhtar')";
//		String sql2 = "insert into login values(222,'nau25','Naushad','Akhtar')";
//		Statement statement=connection.createStatement();
//		statement.addBatch(sql1);
//		statement.addBatch(sql2);
//		int count[] = statement.executeBatch();
//		System.out.println("Total records inserted is: "+count);
		
	}
}
