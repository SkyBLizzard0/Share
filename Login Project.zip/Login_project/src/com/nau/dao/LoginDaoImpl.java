package com.nau.dao;

import java.util.List;

import com.nau.model.Login;

public class LoginDaoImpl  extends LoginDaoAdaptor{
@Override
public Integer saveUser(List<Login> logins) {
	// TODO Auto-generated method stub
	System.out.println("in dao");
	logins.forEach(System.out::println);
	return null;
}
}
