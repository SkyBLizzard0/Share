package com.nau.model;

//select * from login where userid=userid and password=password
//insert into login values(userId, password, fname, lname)
//select * from login where userid=userid
//update login set password=newpassword where userid=userid
//delete from login where userid=userid
public class Login {

	private Integer userId;
	private String password;
	private String lname;
	private String fname;
	public Login() {
		
	}
	public Login(Integer userId, String password, String lname, String fname) {
		super();
		this.userId = userId;
		this.password = password;
		this.lname = lname;
		this.fname = fname;
	}
	public Integer getUserId() {
		return userId;
	}
	public void setUserId(Integer userId) {
		this.userId = userId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	@Override
	public String toString() {
		return "Login [userId=" + userId + ", password=" + password + ", lname=" + lname + ", fname=" + fname + "]";
	}

	
	
}
